//
// Created by Al Dorado on 15.11.15.
//
#include <iostream>
#include <fstream>
#include "tableau.h"
#ifndef SIMPLEX_UTILITIES_H
#define SIMPLEX_UTILITIES_H

using namespace std;

Tableau filereader(string pathToFile);

#endif //SIMPLEX_UTILITIES_H
