# simplex C++ Implementation
C++ implementation of the simplex algorithm

For the course 'Optimierung und Simulation' at the University of Vienna in the winter term 2015/2016.
